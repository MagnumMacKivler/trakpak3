Welcome to Magnum's Trakpak V2! This .txt file contains information regarding:

Important Notes (Line 9)
Installation Instructions (Line 22)
Prefab Descriptions (Line 40)
A Basic Inventory List (Line 232)

===============
IMPORTANT NOTES
===============

1- The folder "Prefabs\TP2 Misc" contains a prefab called "Switch Initializer."
EVERY MAP NEEDS TO HAVE ONE OF THESE! Seriously. If you don't have it, your switches may malfunction.

2- Instead of packaging the models with the map, which can take up an absurd amount of space, please
reference Trakpak's workshop addon instead.
If you insist on packaging the models with the map for whatever reason, please ask Me (Magnum MacKivler)
about it as a courtesy.

3- Trakpak2 utilizes some models and materials from Trakpak(1). Don't forget to extract that too!
=========================
INSTALLATION INSTRUCTIONS
=========================
This was written assuming you've never mapped before.

1- Extract "maps," "materials," and "models" to your game's content folder.
So if you were using the EP2 Hammer to map (as you should be), you would MERGE the aforementioned
folders from the .zip file WITH
"C:\Program Files (x86)\Steam\SteamApps\common\Half Life 2\hl2\maps",
"C:\Program Files (x86)\Steam\SteamApps\common\Half Life 2\hl2\materials", and
"C:\Program Files (x86)\Steam\SteamApps\common\Half Life 2\hl2\models", respectively.

2- Extract the Prefabs folder to your game's bin folder.
So again if you were using EP2 Hammer to map, you would MERGE the Prefabs folder from the .zip
file WITH
"C:\Program Files(x86)\Steam\SteamApps\common\Half Life 2\bin\Prefabs".
Note that there is no "hl2" after "Half Life 2".

===================
PREFAB DESCRIPTIONS
===================

Trakpak2 has a bunch of prefabs to make your life easier, and there are a lot of them, so I
will be going from folder to folder detailing what each one does.

Most prefabs (aside from the straight road/rail ones) will have a brush with the Skip texture surrounding
it. Use this to align the switch prefab as a whole to a 64-unit grid!

For the purposes of concision, only the left-hand versions of applicable prefabs will be listed.
You should be able to figure out what the right-hand ones do.

--------
TP2 Misc
--------

Switch Initializer: forces all switches into the "main" position on map load. This prevents
both paths of the switch from having physics (which would mean derailments!) Also,
it provides a set of filters to make sure only certain things trip the autoswitches.

Straight Orthogonal: straight brush track, that can only face in the cardinal directions
(North, South, East, West). Great for bridging off-numbered gaps between track pieces.

Straight Rotateable: slightly more expensive straight brush track that can be rotated and vertex-manipulated
as necessary.

Road Orthogonal: like Straight Orthogonal, but for roads instead of rails.

Road Rotateable: like Straight Rotateable, but for roads instead of rails.

Street Generic: brush streets (with sidewalks) that can be rotated to any angle.

r2048 CR Left: double track 90� curved ramp. I made it a prefab because it's 8 total models.

r2048 CR Right: ditto for right-hand turn.

r3072 CR Left: ditto for 3072-radius curved ramps, left-hand turn.

r3072 CR Right: ditto for right-hand turn.

Turntable x5: a turntable with 5 stalls, good for a small roundhouse.

Turntable x9: a turntable with 9 stalls, good for a medium-sized roundhouse.

Turntable x13: a turntable with 13 stops, but in reality can rotate 360� to 24 total positions.

Xing Single NS: an automatic railroad crossing, single track, running North to South.

Xing Single EW: ditto for East to West.

Xing Double NS: double track North to South railroad crossing.

Xing Double EW: ditto for East to West.

Bascule Bridge [N/S/E/W]: a double track fully-functional Bascule Bridge facing in one of the
cardinal directions (N for North, etc.).

-----------------
TP2 Switches 1536
-----------------

1536-radius switches are ideal for yards and terminals, but a bad idea for mainlines.

left_168: a 16.75� yard turnout, great for starting a yard ladder.

left_168_yard: a 16.75� yard turnout, rotated at 16.75�, great for continuing a yard ladder.
To even the ladder off at the end, use "models\trakpak2\curves\r1536\left_168.mdl".

left_45: a 45� yard turnout. Also suitable for branch lines and street running.

left_siding: a siding switch, that results in two parallel tracks spaced 256 units apart.

left_crossover: two switches built into one, it allows a train to "cross over" from one side of
double track to the other.

diamond_crossover: also known as a scissors diamond, it combines a left and right crossover into
one compact, albeit complex switch arrangement. Scarcer than chicken's teeth in North America.

left_slip: a double slip switch, which allows for four different paths. Commonly found in passenger terminals.

wye_225: a 22.5� wye. wye switches go left and right instead of left and straight, or right and straight.

wye_45: ditto for a 45� turn.

wye_parallel: a wye that results in two parallel tracks, like a siding switch.

-----------------
TP2 Switches 2048
-----------------

In a perfect world, 2048-radius curves and switches would be reserved only for branch lines and yards.
Since we're stuck with the Hammer grid, don't be ashamed if you have to use them on mainlines.

left_225: a mid-radius 22.5� turnout.
left_45: ditto for a 45� turn.

left_225_autoreset: features an auto-reset trigger so when a train is done with the switch, it resets
to the "main" (straight) position. By the way, all crossovers do this as well.

left_45_autoreset: ditto for a 45� turn.

left_siding: a mid-radius siding switch.

left_crossover: a crossover switch suitable for branch lines, or occasionally mainlines if
trains aren't moving too fast.

left_doublejunction: two 45� interlocking turnouts, for when a double track line diverges.
you don't see many of these in North America either.
All doublejunctions are equipped with autoresets.

wye_225: a 22.5� wye switch.

wye_45: ditto for a 45� turn.

wye_45_double: a 45� wye doublejunction. You should almost never need to use these.

NEW!

left_45_2304: Basically the outer switch of a double junction, for when you want a line to split off from
a double track mainline. The switch is "inverted" (Curved Path is default).


-----------------
TP2 Switches 3072
-----------------

3072 switches are good for mainlines and branch lines alike, and offer nice, gentle curves for
any trains that traverse them. All switches (minus the wyes) from here on out are equipped with auto-resets.
You may also notice that from this point onward, the switches are 8 units higher than the previous ones.
This is because mainlines have extra ballast and stronger grading to suppor heavy and faster trains.

left_225: honestly do I really need to explain this again?

left_45: you already know what these do.

left_siding: old news again.

left_crossover: yup.

left_doublejunction: uh-huh.

wye_225: mmm-hmm.

wye_45: is it break time yet?

-----------------
TP2 Switches 4096
-----------------

4096-radius curves are enormous. Being the real estate hogs that they are, you should only put them
on high-speed mainlines.

left_225: Sally sells sea shells by the sea shore.

left_45: Sally shells she sells by the she sore.

left_siding: Shally shelves shoe elves by the see saw.

left_crossover: Shelly salvages shitty shelves... ehh forget it.

---------------------------------------------
TP2 Electrification Lefthand/Righthand/Double
---------------------------------------------

Because making curved catenary models (with poles) would inflate the size of Trakpak2 by threefold,
I decided to just make the wires and have you fill in the poles. To make your life less miserable, I
have done most of the grunt work for you.

I think I've earned a little laziness, so I'm just going to tell you how to interpret my nomenclature instead.

Exhibit A: "r1536_90"

A 1536-radius 90� single track turn with electrification. Since the 90� turns are symmetrical, just rotate
the prefab as needed. If the poles are on the wrong side for your liking, use the one in the other folder.

Exhibit B: "r2048_left_45"

The left/right designation now comes into play because 45� turns aren't rotateable
(in less than 90� increments). Note the radius has also increased to 2048.

Exhibit C: "r3072_cr_left"

The new element here is the "cr" which stands for "curved ramp".



One final note before concluding this section: all the Double Track catenary prefabs come with
the "double poles" by default. That is, one pole between the two tracks which supports both wires.
If you want gantries instead, select all the pole models and change them from "pole_double" to "gantry_double".


==============
INVENTORY LIST
==============

Contained here is a brief, general list of what Trakpak2 has to offer in terms of raw models.

Straights: straight track of varying lengths. Unlike with real train sets, you will
never run out of these babies!

Curves: Trakpak2 has four principle radii (1536, 2048, 3072, 4096) and three extra radii
(2304, 3328, 4352) for double track curves. Each curve radius has both left and right variations
and angles ranging from 22.5� up to 90�. Additionally, the principle radii feature "bend" curves for
when you need to nudge the line over just a bit, and have it come out parallel with the original track.

Grades: a collection of ramp tracks. Trakpak2 now features two different grade levels (3.2% and 1.6%)
as well as 3072-radius curved ramps.

Turnouts: you should probably avoid this folder since making switches by hand is a pain in the ass.
Use the prefabs instead!

Groundthrows: Trakpak2 has a much larger selection of ground throws for your switches, including
low-profile throws, switch cubes, automatic switch boxes, and high-profile throws.
The switch cubes have multiple skins for the handed-ness of the turnout:
Skins 0 and 2 for Left-handed turnouts.
Skins 1 and 3 for Right-handed turnouts.

Special: from bridges to turntables, bumpers to check rails. If it's track, and doesn't belong
anywhere else, you can probably find it in here.

Misc: trackside stuff that doesn't fit anywhere else, like whistle posts.

Roads: in addition to providing models for the easy construction of railroad crossings, Trakpak2 also
features models for making complex road systems, street networks, and even street-running trackage.

Tunnels: a set of rudimentary tunnel models, in your choice of brick or concrete.

Signals: a collection of various signals and signaling paraphernalia, like signal masts and bridges,
and of course, the signal heads themselves. Signal types vary from the ubiquitous Color Light (CL) to
the exotic Colored Position Light (CPL) and beyond.

Catenaries: overhead wires, gantries, poles, and the like for electrifying your routes.

-----

And that's about it! If you have any questions or requests, please contact me (Magnum MacKivler).
You can usually find me on FC&N Train Build, seeing how I kinda run the place.